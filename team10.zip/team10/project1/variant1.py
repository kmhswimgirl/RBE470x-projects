# This is necessary to find the main code
import sys
sys.path.insert(0, '../../Bomberman')
sys.path.insert(1, '..')

# Import necessary stuff
from game import Game # type: ignore

# TODO This is your code!
sys.path.insert(1, '../teamNN')

# Uncomment this if you want the empty test character
# from testcharacter import TestCharacter

# Uncomment this if you want the interactive character
from interactivecharacter import InteractiveCharacter
from character_one import CharacterOne

# Add the custom character
from astarcharacter import AStarCharacter

# Create the game
g = Game.fromfile('map.txt')

# TODO Add your character

# Uncomment this if you want the test character
# g.add_character(TestCharacter("me", # name
#                               "C",  # avatar
#                               0, 0  # position
# ))

# # Uncomment this if you want the interactive character
# g.add_character(InteractiveCharacter("me", # name
#                                      "C",  # avatar
#                                      0, 0  # position
# ))

# add the custom A* character
g.add_character(AStarCharacter("me", # name
                                "C",  # avatar
                                0, 0  # position
))

# Uncomment this if you want the interactive character
# g.add_character(InteractiveCharacter("me", # name
#                                      "C",  # avatar
#                                      0, 0  # position
# ))

# Run!

# Use this if you want to press ENTER to continue at each step
#g.go(0)

# Use this if you want to proceed automatically
g.go(1)
